Colour schemes for built-in script editor.

Use `Options > Editor properties` to import these.
